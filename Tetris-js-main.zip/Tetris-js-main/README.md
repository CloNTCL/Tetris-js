# Tetris-js

## Authors :

- Sarah Plichta

- Clorinda NGUOKO

- Rémi R MATHIVANAN

## Description :

A tetris game made in with html/css/js.
